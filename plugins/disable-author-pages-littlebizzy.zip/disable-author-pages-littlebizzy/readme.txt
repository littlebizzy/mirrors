=== Disable Author Pages ===

Contributors: littlebizzy
Tags: disable, author, pages, archive, archives, links, 404, redirect, homepage, remove, hide
Requires at least: 4.4
Tested up to: 4.7
Stable tag: 1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Completely disables author archives which then become 404 errors, converts author links to homepage links, and works with or without fancy permalinks.

== Description ==

Completely disables author archives which then become 404 errors, converts author links to homepage links, and works with or without fancy permalinks.

== Installation ==

1. Upload "Disable Author Pages by LittleBizzy" folder to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress
3. Navigate to the "Disable Author Pages" page available through the left menu

== Changelog ==

= 1.0 =
* Initial release