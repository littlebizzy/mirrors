=== Disable Emojis ===

Contributors: LittleBizzy
Tags: disable emojis, emojis, disable, emoji, smileys, smiley, icons, icon, speed
Requires at least: 4.4
Tested up to: 4.8
Stable tag: 1.0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Completely disables both the old and new versions of WordPress emojis, removes the corresponding javascript calls, and improves page loading times.


== Description ==

Completely disables both the old and new versions of WordPress emojis, removes the corresponding javascript calls, and improves page loading times.

Unlike some other similar plugins, this plugin forces the "convert emoticons" option in WordPress settings to be unregistered directly using a hook. If users deactivate this plugin, that setting will return to previous value (whatever it was set to prior to activating this plugin) so it's very conflict free.


== Installation ==

1. Upload "Disable Emojis LittleBizzy" folder to the "/wp-content/plugins/" directory
2. Activate the plugin through the "Plugins" menu in WordPress

== Changelog ==

= 1.0.1 =
* update plugin meta

= 1.0.0 =
* initial release